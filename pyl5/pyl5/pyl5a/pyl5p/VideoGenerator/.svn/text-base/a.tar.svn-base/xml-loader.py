#!/usr/bin/python

import xml.dom.minidom
import pprint

SCRIPT_XML_FILENAME = '/Users/dwilches/DWilches/Code/ImageProcessing/Execution/script.xml'

# Cargar el archivo XML a memoria, en una estructura mas facilmente entendible
# {
print ('Parsing: ' + SCRIPT_XML_FILENAME)

doc = xml.dom.minidom.parse(SCRIPT_XML_FILENAME)

actors = {}

for xmlActor in doc.getElementsByTagName('actor'):
    a = {}

    # Asigno los valores de los atributos de este elemento
    for attr_key in xmlActor.attributes.keys():
        a[attr_key] = xmlActor.getAttribute(attr_key)

    #Asigno el valor de la posicion del elemento
    for xmlPosition in xmlActor.getElementsByTagName('position'):
        a['position'] = ( xmlPosition.getAttribute('x') , xmlPosition.getAttribute('y') , xmlPosition.getAttribute('z') )

    # Asigno la trayectoria que tiene este elemento
    a['trayectoria'] = []
    for xmlPoint in xmlActor.getElementsByTagName('point'):
        a['trayectoria'].append( ( xmlPoint.getAttribute('x') , xmlPoint.getAttribute('y') , xmlPoint.getAttribute('z') ) )

    # Por ultimo agrego este elemento a la lista de actores de la composicion, pero me cuido de no sobreescribir otro actor que tenga el mismo nombre
    currIndex = 0
    assetName = a['asset']
    while assetName in actors: # Seria mas bonito con un do..while , pero Python no lo tiene
        assetName = "%s_%d" % ( a['asset'] , currIndex )
        currIndex += 1
    actors[assetName] = a

# }

# Invocar al API de Blender para crear los actores y acomodar todos los elementos en la escena
# {

import bpy

# Mover la camara al lugar donde debe quedar (en caso de que nos hayan dado esta informacion para la camara)
pprint.pprint(actors['SBCamera'])

# }

#pprint.pprint(actors)
